Overleaf source package — multilingual-grounding-pilot

Upload this ZIP to a new Overleaf project. Select draft.tex as the main file.
Use pdfLaTeX with BibTeX (the normal latexmk build). The standard acmart class
provides the ACM manuscript, single-column format. No private or external files
are needed. refs.bib is the active bibliography; references.bib is an identical
compatibility copy. Both figures are numeric plots generated from recorded results.

Author: Saurav K. Aryal, Howard University
Artifact: https://github.com/Saurav-K-Aryal/multilingual-grounding-pilot
