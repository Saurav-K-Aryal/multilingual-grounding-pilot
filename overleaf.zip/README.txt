Source Use and Cultural Image Questions
Saurav K. Aryal, Howard University
Updated November 1, 2026

Upload draft.tex, refs.bib and figures/ to Overleaf; choose draft.tex as the main file. The package uses ACM manuscript single-column format. references.bib is an identical compatibility copy; draft.tex uses refs.bib only.

Completed pilot observations are unchanged. The future-work section now describes a Swahili core and gated Twi replication using a dated public Prolific audience snapshot. No new human recruitment, Twi experiment or native-answer assessment was conducted. The previous October 31 manuscript is retained in archive/20261031/ in the public repository.

Repository: https://github.com/Saurav-K-Aryal/multilingual-grounding-pilot
